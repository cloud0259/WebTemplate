﻿namespace $safeprojectname$.Applications
{
    public interface IApplicationService
    {
    }
}
