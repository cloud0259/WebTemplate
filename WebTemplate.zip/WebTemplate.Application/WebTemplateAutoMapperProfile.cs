﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using $safeprojectname$.Dtos.Users;
using $ext_safeprojectname$.Domain.Users;
using $ext_safeprojectname$.Infrastructure.Identity.Models;

namespace $safeprojectname$
{
    public class $safeitemrootname$:Profile
    {
        public $safeitemrootname$() 
        {
            CreateMap<CreateUpdateUserDto, ApplicationUser>();
            CreateMap<ApplicationUser, UserDto>();
        }
    }
}
