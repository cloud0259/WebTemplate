﻿using System.Linq.Expressions;
using $safeprojectname$.Entities;

namespace $safeprojectname$.Repositories
{
    public interface IRepository<TEntity,TKey>: IReadOnlyRepository<TEntity,TKey> where TEntity : IEntityBase
    {
        Task<TEntity> InsertAsync(TEntity entity, CancellationToken cancellationToken = default);
        Task InsertManyAsync(IEnumerable<TEntity> entity, CancellationToken cancellationToken = default);
        Task UpdateAsync(TEntity entity, bool includeDetails = false, CancellationToken cancellationToken = default);
        Task UpdateManyAsync(IEnumerable<TEntity> entity, CancellationToken cancellationToken = default);
        Task DeleteAsync(TEntity entity, CancellationToken cancellationToken = default); 
    }
}
