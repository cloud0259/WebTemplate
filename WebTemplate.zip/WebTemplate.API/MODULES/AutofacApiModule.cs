﻿using Autofac;
using Autofac.Core;
using MediatR.Extensions.Autofac.DependencyInjection;
using MediatR.Extensions.Autofac.DependencyInjection.Builder;
using System.Reflection;
using $ext_safeprojectname$.Application.Modules;
using $ext_safeprojectname$.Infrastructure.Modules;

namespace $safeprojectname$.Modules
{
    public class AutofacApiModule: Autofac.Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterModule(new $ext_safeprojectname$ApplicationAutofacModule());
            builder.RegisterModule(new $ext_safeprojectname$InfrastructureAutofacModule());
            var configuration = MediatRConfigurationBuilder
            .Create(ThisAssembly)
            .WithAllOpenGenericHandlerTypesRegistered()
            .Build();

            builder.RegisterMediatR(configuration);
        }
    }
}
