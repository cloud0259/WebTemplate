﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using $ext_safeprojectname$.Domain.Users;
using $safeprojectname$.EntityFrameworkCore.EntityTypeConfigurations;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using $safeprojectname$.Identity.Models;
using $ext_safeprojectname$.Domain;
using System.Reflection.Emit;

namespace $safeprojectname$.EntityFrameworkCore
{
    public class $safeitemrootname$  : IdentityDbContext<ApplicationUser>
    {
        protected $safeitemrootname$ ()
        {
        }

        public $safeitemrootname$ (DbContextOptions <$safeitemrootname$ > options) 
            : base(options) 
        {

        }

        //Add DbSet 
        //Example: public DbSet<User> Users{get;set;}
        //public DbSet<User> Users { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            //modelBuilder.ApplyConfiguration(new UserEntityTypeConfiguration());

            /* applying the configuration
            modelBuilder.Entity<user>().ToTable("users");

            or use entitytypeconfiguration file on entitytypeconfigurations folder
            this file
            modelbuilder.applyconfiguration(new userentitytypeconfiguration());

            public class UserEntityTypeConfiguration : IEntityTypeConfiguration<User>
            {
               public void Configure(EntityTypeBuilder<User> builder)
               {
                   builder.ToTable("Users");
                   //Add entity configuration
               }
            }*/
        }
    }
}
