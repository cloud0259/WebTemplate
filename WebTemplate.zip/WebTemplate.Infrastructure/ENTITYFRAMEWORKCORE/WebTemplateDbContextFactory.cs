﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.EntityFrameworkCore
{
    public class $safeitemrootname$ : IDesignTimeDbContextFactory<$ext_safeprojectname$DbContext>
    {
        public $ext_safeprojectname$DbContext CreateDbContext(string[] args)
        {
            ConfigurationBuilder confBuilder = new ConfigurationBuilder();
            confBuilder.AddJsonFile(Path.Combine(Directory.GetCurrentDirectory(), "appsettings.json"))

                .AddJsonFile(Path.Combine(Directory.GetCurrentDirectory(), "appsettings.Production.json"))
                .AddJsonFile(Path.Combine(Directory.GetCurrentDirectory(), "appsettings.secret.json"));

            IConfigurationRoot configurationRoot = confBuilder.Build();

            var builder = new DbContextOptionsBuilder<$ext_safeprojectname$DbContext>();

            builder.UseSqlServer(configurationRoot.GetConnectionString("DataBase"));

            $ext_safeprojectname$DbContext context = new $ext_safeprojectname$DbContext(builder.Options);

            return context;
        }
    }
}
