﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using $safeprojectname$.Identity.Providers;
using $safeprojectname$.Identity.Security.Claims;

namespace $safeprojectname$.Identity.Models
{
    public class CurrentUser : ICurrentUser
    {
        private readonly ClaimsIdentity? _identity;

        public CurrentUser(IPrincipalProvider provider)
        {
            _identity = provider.User.Identity as ClaimsIdentity;
        }

        public bool IsAuthenticated => _identity.IsAuthenticated;
        public string? UserId => _identity.Claims.FirstOrDefault(x => x.Type! == $ext_safeprojectname$ClaimType.UserId).Value;
        public string? Name => _identity.Claims.FirstOrDefault(c => c.Type == $ext_safeprojectname$ClaimType.Name).Value;
        public string? Role => _identity.Claims.FirstOrDefault(c => c.Type == $ext_safeprojectname$ClaimType.Role).Value;
        public string? Email => _identity.Claims.FirstOrDefault(x => x.Type == $ext_safeprojectname$ClaimType.Email).Value;
    }
}
