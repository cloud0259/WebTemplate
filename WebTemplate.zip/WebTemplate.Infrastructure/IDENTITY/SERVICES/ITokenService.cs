﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using $safeprojectname$.Identity.Models;

namespace $safeprojectname$.Identity.Services
{
    public interface ITokenService
    {
        Task<TokenResponse> Authenticate(TokenRequest request);
    }
}
